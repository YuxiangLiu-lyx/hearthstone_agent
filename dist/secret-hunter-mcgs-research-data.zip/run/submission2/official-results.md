# HW2 Results - chickchickman4 (Submission 2)

| Opponent | Games | Wins | Losses | Draws | Forfeits | Points |
|---|---:|---:|---:|---:|---:|---|
| bot1 | 6 | 5 | 1 | 0 | 0 | 8 (5 completion pts + 3 win pts) |
| bot2 | 4 | 2 | 2 | 0 | 0 | 1 |
| astra | 4 | 1 | 3 | 0 | 0 | 1 bonus |
| **Total** | 14 | 8 | 6 | 0 | 0 | **10 (9 base + 1 bonus)** |

Losses exclude forfeits. This evaluation score excludes ladder points and any final late adjustment.
